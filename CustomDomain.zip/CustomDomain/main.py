import flask as fl
import socket , os
app = fl.Flask(__name__)
methods = ["POST","GET"]
@app.route("/",methods=methods)
def home():
    return fl.render_template("index.html",ip=socket.gethostbyname(socket.gethostname()))
@app.route("/create/",methods=methods)
def create():
    og = fl.request.form["og"]
    dream = fl.request.form["dream"]
    if os.listdir("db").__contains__(f"{dream}.txt"):
        return "<center><h2>Your link already exists</h2></center>"
    else:
        open(f"db\\{dream}.txt","w").write(og)
        return f"<center><h2>Your new link is: http://{socket.gethostbyname(socket.gethostname())}:6767/custom/{dream}</h2></center>"
@app.route("/custom/<dream>",methods=methods)
def read(dream):
    if os.listdir("db").__contains__(f"{dream}.txt"):
        link = open(f"db\\{dream}.txt","r").read()
        protocol = ""
        for char in range(9):
            protocol = protocol + link[char]
        if protocol != "https://":
            protocol = ""
            for char in range(8):
                protocol = protocol + link[char]
            if protocol != "http://":
                return fl.redirect(f"https://{link}")
            else:
                return fl.redirect(link)
        else:
            pass
    else:
        return "This page doesn`t exists"
if __name__ == "__main__":
    app.run(host="0.0.0.0",port=6767)